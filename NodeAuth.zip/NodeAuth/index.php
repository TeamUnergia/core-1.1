<html>
<head>
	<title> Unergia Payment </title>
	<meta name="viewport" content="width=device-width">
	<style>
.grid { 
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  grid-gap: 20px;
  align-items: stretch;
  }
.grid > article {
  border: 1px solid #ccc;
  box-shadow: 2px 2px 6px 0px  rgba(0,0,0,0.3);
}
.grid > article img {
  max-width: 100%;
}
.text {
  padding: 0 20px 20px;
}
.text > button {
  background: gray;
  border: 0;
  color: white;
  padding: 10px;
  width: 100%;
  }
</style>
</head>

<body>
	<div class="grid" id="cardgrid">
  <article>
    <img src="/pix/samples/23m.jpg" alt="Sample photo">
    <div class="text">
      <h3>Seamlessly visualize quality</h3>
      <p>Collaboratively administrate empowered markets via plug-and-play networks.</p>
	  <p>Cost of the project: ₹50000</p>
      <button id="button1" onClick="button1()">Pay</button>
	  <script>
		function button1(){
			window.open('http://localhost:3000');
			<?php
				$cost=50000;
				echo $cost;
			?>
			
		}
		</script>
	 
    </div>
  </article>
  <article>
    <img src="/pix/samples/24m.jpg" alt="Sample photo">
    <div class="text">
      <h3>Completely Synergize</h3>
      <p>Dramatically engage seamlessly visualize quality intellectual capital without superior collaboration and idea-sharing.</p>
      <p>Cost of the project: ₹70000</p>
	  <button onClick="window.open('http://localhost:3000');">Pay</button>
    </div>
  </article>
  <article>
    <img src="/pix/samples/22l.jpg" alt="Sample photo">
    <div class="text">
      <h3>Dynamically Procrastinate</h3>
      <p>Completely synergize resource taxing relationships via premier niche markets.</p>
	  <p>Cost of the project: ₹60000</p>
      <button onClick="window.open('http://localhost:3000');">Pay</button>
    </div>
  </article> 
  <article>
    <img src="/pix/samples/15l.jpg" alt="Sample photo">
    <div class="text">
      <h3>Best in class</h3>
      <p>Imagine jumping into that boat, and just letting it sail wherever the wind takes you...</p>
	  <p>Cost of the project: ₹55000</p>
      <button onClick="window.open('http://localhost:3000');">Pay</button>
    </div>
  </article>
  <article>
    <img src="/pix/samples/25m.jpg" alt="Sample photo">
    <div class="text">
      <h3>Dynamically innovate supply chains</h3>
      <p>Holisticly predominate extensible testing procedures for reliable supply chains.</p>
	  <p>Cost of the project: ₹65000</p>
      <button onClick="window.open('http://localhost:3000');">Pay</button>
    </div>
  </article>
  <article>
    <img src="/pix/samples/16l.jpg" alt="Sample photo">
    <div class="text">
      <h3>Sanity check</h3>
      <p>Objectively innovate empowered manufactured products whereas parallel platforms.</p>
	  <p>Cost of the project: ₹48000</p>
      <button onClick="window.open('http://localhost:3000');">Pay</button>
    </div>
  </article>
</div>
	
</body>
</html>

