<html>
<head>
	<title> Welcome to Unergia Payment Portal </title>
</head>
<body>
<div id="topay">
	<form action="payrazor.php" method="POST">
		How much are you willing to pay?:<br>
		<input type="number" name="amounttopay"> <br>
	<?php
	
		if((isset($_POST['amounttopay'])) )
			{
				$amount = $_POST['amounttopay']; 
				echo $amount;
			}

	?>
	<br>
	<button type="submit">Pay</button>
	 </form>
	 </div>
	 
</body>
</html>