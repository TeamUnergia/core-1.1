<?php
include("index.php");
include("pay.php");
?>
<html>
<head>
	<title> Unergia Payment </title>
	<meta name="viewport" content="width=device-width">
</head>
<body>
		<p> You are willing to pay <p id="percent"></p><p> Thank you! </p>
		<script>
		
			percentinv=(<?php echo $amount; ?>/<?php echo $cost; ?>)*100;
			if(percentinv>100)
				percentinv=100;
		</script>
		<script>document.getElementById('cardgrid').style.display = 'none';</script>
        <script>document.getElementById('topay').style.display = 'none';</script>
		<script>document.getElementById('percent').innerHTML=percentinv+"% of the total cost";</script>

<form action="/purchase" method="POST">

	<script
		src="https://checkout.razorpay.com/v1/checkout.js"
		data-key="rzp_test_v5adMQcCcerydV"
		data-amount=<?php echo $amount*100; ?>
		data-buttontext="Pay with Razorpay"
		data-name="Unergia"
		data-description="Purchase Description"
		data-image="https://your-awesome-site.com/your_logo.jpg"
		data-prefill.name="Alapan Kar"
		data-prefill.email="test@test.com"
		data-theme.color="#F37254"
	}
	></script>
	<input type="hidden" value="Hidden Element" name="hidden">
</form>
</body>