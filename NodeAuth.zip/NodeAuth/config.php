<?php
$razor_api_key = "rzp_test_Gdo1p0yhWcUpbx";
?>